Page({
  data: {
    imgUrls: [
      {
        src: '../../image/xg-1.jpg',
        name: ''
      },
      {
        src: '../../image/xg-2.jpg',
        name: ''
      },
      {
        src: '../../image/xg-3.jpg',
        name: ''
      },
    ],
    img:'../../image/xg-3.jpg',
    indicatorDots: true,
    current: 0,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    swiperTotal: 3,
    swiperCurrent: 1,
    actionSheetHidden: true,

    show: true
  },
  listenerButton: function () {
    this.setData({
      actionSheetHidden: !this.data.actionSheetHidden
    });
  },
  listenerActionSheet: function () {
    this.setData({
      actionSheetHidden: !this.data.actionSheetHidden
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '转发小程序',
      path: 'pages/activity-details/activity-details'
    }
  },
  shopDetails: function () {
    wx.navigateTo({
      url: '../shop-details/shop-details'
    })
  },
  MainActivity: function () {
    wx.navigateTo({
      url: '../activity-details/activity-details'
    })
  },
  convas: function (bgImg, ewrImg, shopImg) {
    var that = this;
    const ctx = wx.createCanvasContext('shareImg');
    //主要就是计算好各个图文的位置
    ctx.drawImage('../../image/canvas-bg.jpg', 0, 0, 545, 771)
    ctx.drawImage(bgImg, 0, 0, 545, 340);
    ctx.drawImage(ewrImg, 170, 500, 210, 210);
    ctx.drawImage(shopImg, 245, 575, 60, 60);
    ctx.setTextAlign('center');
    ctx.setFillStyle('#333');
    ctx.setFontSize(40)
    ctx.fillText(that.data.shop_name, 545 / 2, 420)
    ctx.stroke()
    ctx.draw()
  },
  /**
  * 生成分享图
  */
  share: function () {
    var that = this
    wx.showLoading({
      title: '努力生成中...'
    })
    wx.canvasToTempFilePath({
      x: 0,
      y: 0,
      width: 545,
      height: 771,
      destWidth: 545,
      destHeight: 771,
      canvasId: 'shareImg',
      success: function (res) {
        that.setData({
          prurl: res.tempFilePath,
          hidden: false
        })
        wx.hideLoading()
      },
      fail: function (res) {

      }
    })
  },
  /**
   * 保存到相册
  */
  save: function () {
    var that = this
    //生产环境时 记得这里要加入获取相册授权的代码
    wx.saveImageToPhotosAlbum({
      filePath: that.data.prurl,
      success(res) {
        wx.showModal({
          content: '图片已保存到相册，赶紧晒一下吧~',
          showCancel: false,
          confirmText: '好的',
          confirmColor: '#72B9C3',
          success: function (res) {
            if (res.confirm) {
              that.setData({
                hidden: true
              })
            }
          }
        })
      }
    })
  },

  playvedio: function (e) {
    let vediocon = wx.createVideoContext("myVideo", this)
    vediocon.play()
    console.log(vediocon)
    this.setData({
      show: false
    })
  },
  /*
 *视频播放完毕重新上封面
 */
  endvedio: function () {
    let vediocon = wx.createVideoContext("myvedio", this)
    // vediocon.play()
    console.log(vediocon)
    this.setData({
      show: true
    })
  },
  /**
     * 当发生错误时触发error事件，event.detail = {errMsg: 'something wrong'}
     */
  videoErrorCallback: function (e) {
    console.log('视频错误信息:')
    console.log(e.detail.errMsg)
  },
  linkfillUserInfo: function () {
    wx.navigateTo({
      url: '../fill-userinfo/fill-userinfo'
    })
  },
})